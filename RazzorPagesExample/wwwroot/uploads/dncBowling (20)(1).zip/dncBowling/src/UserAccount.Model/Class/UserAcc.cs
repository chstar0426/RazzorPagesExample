﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace UserAccount.Models
{
    public class UserAcc
    {
        
        public string Id { get; set; }

        [Display(Name = "아이디")]
        public string UserId { get; set; }

        [Display(Name = "패스워드")]
        [Required, StringLength(5, MinimumLength = 2, ErrorMessage ="2자에서 5자 이내입니다")]
        public string Password { get; set; }

        [Display(Name = "별명")]
        public string NicName { get; set; }

        [Display(Name = "사용자권한")]
        public string UserGroup { get; set; }
    }
}
