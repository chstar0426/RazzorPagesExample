﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserAccount.Models
{
    public interface IUserAccRepository
    {
        UserAcc LogOnAcc(UserAcc model);

        UserAcc GetAcc(int Id);

        int ModifyAcc(int Id, string NicName, string Password);

    }
}
