﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace UserAccount.Models
{ 
    public class UserAccRepository : IUserAccRepository
    {
        private readonly SqlConnection _db;

        public UserAccRepository(IConfiguration config)
        {
            //_db = new SqlConnection("Server=(localdb)\\mssqllocaldb;Database=UserAccount.Database;Integrated Security=true;");

            _db = new SqlConnection(config.GetConnectionString("UserAccConnection"));
            
        }

        public UserAcc GetAcc(int Id)
        {
            string sql = @"select [Id], [UserId], [Password], [NicName], [UserGroup] from UserAcc 
                        Where Id = @Id";

            return _db.Query<UserAcc>(sql, new { Id }).SingleOrDefault();

        }

        public UserAcc LogOnAcc(UserAcc model)
        {
            string sql = @"select [Id], [UserId], [Password], [NicName], [UserGroup] from UserAcc 
                        Where UserId = @UserId and Password = @Password";

            return _db.Query<UserAcc>(sql, new { model.UserId, model.Password }).SingleOrDefault();
             
            
        }

        public int ModifyAcc(int Id, string NicName, string Password)
        {
            string sql = string.Empty;

            
            if(string.IsNullOrEmpty(Password))
            {
               sql = @"Update UserAcc Set NicName=@NicName
                        Where Id=@Id";

                return _db.Execute(sql, new { NicName, Id});

            }
            else
            {
                sql = @"Update UserAcc Set NicName=@NicName, Password = @Password
                        Where Id=@Id";

                return _db.Execute(sql, new { NicName, Password, Id });

            }
            
        }
    }
}
