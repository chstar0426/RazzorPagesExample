﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using dncBowling.Models;
using System.Security.Claims;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace dncBowling.Controllers
{
    public class UserAccountController : Controller
    {
        private readonly IUserAccRepository _repo;

        public UserAccountController(IUserAccRepository repo)
        {
            _repo = repo;
        }

        // GET: /<controller>/
        public IActionResult Login(string returnUrl=null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(UserAcc model, string returnUrl = null)
        {
            if (ModelState.IsValid)
            {

                var User = _repo.LogOnAcc(model);
                if (User != null)
                {
                    var claims = new List<Claim>()
                    {
                        new Claim("Id", User.Id),
                        new Claim("UserId", User.UserId),
                        new Claim("NicName", string.IsNullOrEmpty(User.NicName)?"이름없음":User.NicName),
                        new Claim("UserGroup", User.UserGroup)

                    };
                    var ci = new ClaimsIdentity(claims, model.Password);

                    await HttpContext.Authentication.SignInAsync("Cookies", new ClaimsPrincipal(ci));


                    if (string.IsNullOrEmpty(returnUrl))
                    {
                        return LocalRedirect("/Home/Index");

                    }
                    return LocalRedirect(returnUrl);

                }


            }
            ViewData["ReturnUrl"] = returnUrl;
            ViewData["ErrMsg"] = "로그인 정보 확인 바랍니다.";
            return View();
        }


        public IActionResult Edit()
        {
            
            var acc = _repo.GetAcc(Convert.ToInt32(User.FindFirst("Id").Value));
            return View(acc);
        }

        [HttpPost]
        public IActionResult Edit(int Id, string NicName, string Password)
        {
           int reval=_repo.ModifyAcc(Id, string.IsNullOrEmpty(NicName) ? "" : NicName, Password);

            if (reval>0)
            {
                return RedirectToAction("LogoutWin");

            }

            return View();
            
            

        }

        public IActionResult LogoutWin()
        {
            HttpContext.Authentication.SignOutAsync("Cookies");
            return View();
        }


        public async Task<IActionResult> Logout()
        {
            await HttpContext.Authentication.SignOutAsync("Cookies");
            return Redirect("/Home/Index");
        }

        public IActionResult Forbidden(string returnUrl = null)
        {

            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }


    }
}
