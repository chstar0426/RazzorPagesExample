﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using dncBowling.Models;
using dncBowling.Models.ViewData;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;


// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace dncBowling.Controllers
{
    [Authorize]
    public class BowlingController : Controller
    {
        private readonly IGameRepository _repo;

        public BowlingController(IGameRepository repo)
        {
            _repo = repo;

        }

        // GET: /<controller>/
        public IActionResult Index(string gameKind = "-1", string teamGroup = "", bool cVal = false)
        {

            int PageIndex = 0;
            int PageSize = 10;
            int TotalRecordCount = 0;
            IEnumerable<Game> Games;
            string GameKind = gameKind;
            string TeamGroup = teamGroup;


            if (User.FindFirst("UserGroup").Value == "Admin")
            {
                TeamGroup = string.IsNullOrEmpty(teamGroup) ? "RedPin" : teamGroup;
            }
            else
            {
                TeamGroup = User.FindFirst("UserGroup").Value;
            }



            //[1] 쿼리스트링에 따른 페이지 보여주기
            if (!string.IsNullOrEmpty(Request.Query["Page"].ToString()))
            {
                // Page는 보여지는 쪽은 1, 2, 3, ... 코드단에서는 0, 1, 2, ...
                PageIndex = Convert.ToInt32(Request.Query["Page"]) - 1;
            }


            //[2] 쿠키를 사용한 리스트 페이지 번호 유지 적용(Optional): 
            //    100번째 페이지 보고 있다가 다시 리스트 왔을 때 100번째 페이지 표시
            if (cVal)
            {
                if (!String.IsNullOrEmpty(Request.Cookies["PageNum"]))
                {
                    PageIndex = Convert.ToInt32(Request.Cookies["PageNum"]) - 1;
                }
                else
                {
                    PageIndex = 0;
                }
                GameKind = Request.Cookies["GameKind"];
                TeamGroup = Request.Cookies["TeamGroup"];


            }

            //쿠키저장
            //if (string.IsNullOrEmpty(Request.Cookies["PageNum"]))
            //{
            //    CookieOptions options = new CookieOptions();
            //    options.Expires = DateTime.Now.AddHours(1);
            //    Response.Cookies.Append("PageNum", PageIndex.ToString(), options);
            //    Response.Cookies.Append("GameKind", GameKind, options);
            //    Response.Cookies.Append("TeamGroup", TeamGroup, options);

            //}
            //else
            //{
            //    Response.Cookies.Append("PageNum", PageIndex.ToString());
            //    Response.Cookies.Append("GameKind", GameKind.ToString());
            //    Response.Cookies.Append("TeamGroup", TeamGroup.ToString());
            //}


            ViewBag.PageIndex = PageIndex + 1;
            ViewBag.GameKind = GameKind;
            ViewBag.TeamGroup = TeamGroup;

            ViewBag.Etc = "&TeamGroup=" + TeamGroup + "&gameKind=" + GameKind;


            TotalRecordCount = _repo.GetCount(TeamGroup, Convert.ToInt32(GameKind));
            Games = _repo.GetAllGames(TeamGroup, Convert.ToInt32(GameKind), PageIndex, PageSize);


            // 주요 정보를 뷰 페이지로 전송
            ViewBag.TotalRecord = TotalRecordCount;


            //var aa=(int)(GameKind)Enum.Parse(typeof(GameKind), gameKind);

            return View(Games);
        }

        public IActionResult Details(int id)
        {

            var rModel = new GameDetails();
            var mem = User.FindFirst("UserGroup").Value;




            rModel.Game = _repo.GetGameById(id);

            if (rModel.Game.Bigo == mem || mem == "Admin")
            {
                rModel.Scores = _repo.GetGameScores(id);
            }
            else
            {
                return RedirectToAction("Forbidden", "UserAccount");
            }


            return View(rModel);
        }

        public IActionResult CreateGames()
        {

            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateGames([Bind("PlayTime, Place, GameKind, GameContent, Bigo")] Game model)
        {

            if (ModelState.IsValid)
            {
                
                model.PlayTime = Convert.ToDateTime(model.PlayTime).ToString("yyyy-MM-dd HH:mm");

                int result = _repo.AddGame(model);

                if (result > 0)
                {

                    //쿠키저장
                    if (string.IsNullOrEmpty(Request.Cookies["PageNum"]))
                    {
                        CookieOptions options = new CookieOptions();
                        options.Expires = DateTime.Now.AddHours(1);
                        Response.Cookies.Append("PageNum", "1", options);
                        Response.Cookies.Append("GameKind", ((int)model.GameKind).ToString(), options);
                        Response.Cookies.Append("TeamGroup", model.Bigo, options);

                    }
                    else
                    {
                        Response.Cookies.Append("PageNum", "1");
                        Response.Cookies.Append("GameKind", ((int)model.GameKind).ToString());
                        Response.Cookies.Append("TeamGroup", model.Bigo);
                    }

                    return RedirectToAction("Details", new { id = result });
                }
                else
                {

                    ViewBag.ErrorMessage = "업데이트에 실패하였습니다, 다시 확인바랍니다.";

                }

            }
            return View(model);


        }

        public IActionResult EditGames(int id)
        {
            var model = _repo.GetGameById(id);
            ViewBag.gg = "Aa";
            return View(model);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditGames(int id, [Bind("PlayTime, Place, GameKind, GameContent, Bigo")] Game model)
        {

            if (ModelState.IsValid)
            {
                model.Id = id;
                model.PlayTime = Convert.ToDateTime(model.PlayTime).ToString("yyyy-MM-dd HH:mm");

                int result = _repo.ModifyGame(model);

                if (result > 0)
                {
                    return RedirectToAction("Index", new { cVal = true });
                }
                else
                {

                    ViewBag.ErrorMessage = "업데이트에 실패하였습니다, 다시 확인바랍니다.";

                }

            }
            return View(model);


        }

        public IActionResult CreateScores(int id, int gameNum = 1)
        {
            var rListModel = _repo.TeamsMember(id);
            ViewBag.gameNum = gameNum;
            ViewBag.gameId = id;

            return View(rListModel);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateScores(int id, int gameNum, int[] score)
        {


            int i = 0;

            var sc = new List<Score>();

            var rListModel = _repo.TeamsMember(id);



            foreach (var item in rListModel)
            {
                sc.Add(new Score { TeamId = item.Id, GameNum = gameNum, TeamName = item.TeamName, PlayOrder = item.PlayOrder, Jumsu = score[i] + item.Handi });

                i++;
            }
            int rc = _repo.CreateSocre(sc);

            return RedirectToAction("Details", new { id = id });


        }

        public IActionResult EditScores(int id, int gameNum = 1)
        {
            var rListModel = _repo.MemberScores(id, gameNum);
            ViewBag.gameNum = gameNum;
            ViewBag.gameId = id;

            return View(rListModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EDitScores(int id, int gameNum, int[] score)
        {


            int i = 0;

            var sc = new List<Score>();

            var rListModel = _repo.MemberScores(id, gameNum);



            foreach (var item in rListModel)
            {
                if (score[i] + item.Handi != item.Jumsu)
                {
                    sc.Add(new Score { Id = item.Id, Jumsu = score[i] + item.Handi });

                }

                i++;
            }
            int rc = _repo.EditScores(sc);

            return RedirectToAction("Details", new { id = id });


        }

        public IActionResult CreateTeams(int id, int TeamNum = 1)
        {

            string team = _repo.GameByTeam(id);
            var members = _repo.AllMember(team);
            ViewBag.Id = id;
            ViewBag.TeamNum = TeamNum;

            return View(members);

        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateTeams(int id, int[] teamCnt, string[] selectLst)
        {
            int cnt = 0;
            int teamAsc = 65;

            string[] slc;
            var teams = new List<Team>();


            foreach (var item in teamCnt)
            {
                for (int i = 1; i < item + 1; i++)
                {

                    slc = selectLst[cnt].Split(';');

                    teams.Add(new Team { GameId = id, TeamName = ((Char)teamAsc).ToString(), PlayOrder = i, GameAverage = Convert.ToInt32(slc[1]), Bowler = slc[0] });
                    cnt++;

                }
                teamAsc++;

            }

            int rc = _repo.CreateTeams(teams);

            return RedirectToAction("Details", new { id = id });


        }


        public IActionResult EditTeams(int id)
        {
            string team = _repo.GameByTeam(id);

            var members = new EditTeamMember();
            members.AllMember = _repo.AllMember(id, team);
            members.TeamMember = _repo.TeamBowler(id);


            ViewBag.Id = id;
            ViewBag.TeamNum = members.TeamMember.Where(t => t.TeamName != string.Empty).Select(t => t.TeamName).Distinct().Count();

            return View(members);

        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditTeams(int id, int[] teamCnt, string[] selectLst)
        {

            var TeamMember = _repo.TeamBowler(id);
            var editmember = new EditMember();



            int cnt = 0;
            int teamAsc = 65;

            string[] slc;

            var Addteams = new List<Team>();
            var Editteams = new List<Team>();
            var Remveteams = new List<Team>();

            foreach (var item in teamCnt)
            {
                for (int i = 1; i < item + 1; i++)
                {
                    editmember = TeamMember.Find(m => m.UserId == selectLst[cnt]);

                    if (editmember == null)
                    {
                        slc = selectLst[cnt].Split(';'); slc = selectLst[cnt].Split(';');
                        Addteams.Add(new Team { GameId = id, TeamName = ((Char)teamAsc).ToString(), PlayOrder = i, GameAverage = Convert.ToInt32(slc[1]), Bowler = slc[0] });

                    }
                    else
                    {
                        if (editmember.TeamName != ((Char)teamAsc).ToString() || editmember.PlayOrder != i)
                        {
                            Editteams.Add(new Models.Team { Id = editmember.id, TeamName = ((Char)teamAsc).ToString(), PlayOrder = i });
                        }
                        TeamMember.Remove(editmember);
                    }


                    cnt++;

                }

                teamAsc++;
            }

            foreach (var item in TeamMember)
            {
                Remveteams.Add(new Models.Team { Id = item.id, TeamName = string.Empty, PlayOrder = 0 });

            }



            _repo.CreateTeams(Addteams);

            _repo.EditTeams(Editteams);

            _repo.EditTeams(Remveteams);



            return RedirectToAction("Details", new { id = id });


        }

        public IActionResult PerAverage(string startDate, string endDate, string teamGroup)
        {

            if (User.FindFirst("UserGroup").Value == "Admin")
            {
                teamGroup = string.IsNullOrEmpty(teamGroup) ? "RedPin" : teamGroup;
            }
            else
            {
                teamGroup = User.FindFirst("UserGroup").Value;
            }

            if (string.IsNullOrEmpty(startDate))
            {
                startDate = DateTime.Now.AddMonths(-3).ToString("yyyy-MM-01");
                endDate = Convert.ToDateTime(startDate).AddMonths(3).AddDays(-1).ToString("yyyy-MM-dd");

            }
            ViewBag.StartDate = startDate;
            ViewBag.EndDate = endDate;
            ViewBag.TeamGroup = teamGroup;

            var models = new AverargeCalc();
            models.AvgByMons = _repo.AverageByMonth(startDate + " 00:00", endDate + " 23:59", teamGroup);
            //models.BowlersByTeamAverages = _repo.BowlersByTeamAverageDesc(startDate, endDate);
            models.BowlersByTeamAverages = (from s in models.AvgByMons
                                            group s by new { s.Userid, s.Handi } into g
                                            select new BowlerRank { Userid = g.Key.Userid, Handi = g.Key.Handi, GameAverage = g.Sum(s => s.Cnt) == 0 ? 0 : g.Average(s => s.Average) }).OrderByDescending(s => s.GameAverage).ToList();
            //select new Bowler { Userid = g.Key.Userid, Handi = g.Key.Handi, GameAverage = g.Sum(s => s.Cnt) == 0 ? 0 : (int)(g.Average(s => s.Average) + 0.5) }).OrderByDescending(s => s.GameAverage).ToList();

            models.GameListByPers = _repo.GameListByPer(startDate + " 00:00", endDate + " 23:59", teamGroup);



            return View(models);

        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult RecordAverge(string[] divId, int[] divAvg, string startDate, string endDate, string teamGroup)
        {

            var Bowlers = new List<Bowler>();

            for (int i = 0; i < divId.Count(); i++)
            {
                Bowlers.Add(new Bowler { Userid = divId[i], GameAverage = divAvg[i] });

            }

            int rc = _repo.RecordAverage(Bowlers);

            return RedirectToAction("PerAverage", new { startDate = startDate, endDate = endDate, teamGroup = teamGroup });

        }


        public IActionResult BowlingMember(string teamGroup)
        {
            if (User.FindFirst("UserGroup").Value == "Admin")
            {
                teamGroup = string.IsNullOrEmpty(teamGroup) ? "RedPin" : teamGroup;
            }
            else
            {
                teamGroup = User.FindFirst("UserGroup").Value;
            }

            ViewBag.TeamGroup = teamGroup;

            var Member = _repo.GetAllMember(teamGroup);

            return View(Member);

        }

        [ActionName("DeleteScores")]
        public IActionResult DeleteScoresa(int Id, int gameNum)
        {
            ViewBag.GameNum = gameNum;
            return View(Id);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteScores(int Id, int gameNum)
        {
            _repo.DeleteScores(Id, gameNum);

            return RedirectToAction("Details", new { id = Id });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteGames(int Id)
        {
            _repo.DeleteGames(Id);

            return RedirectToAction("Index");
        }

        public IActionResult IndivRecords(string Id, int gId, string groupKind, string startDate, string endDate, string Indiv)
        {
            
            

            if (User.FindFirst("UserGroup").Value != groupKind && !string.IsNullOrEmpty(groupKind) && User.FindFirst("UserGroup").Value != "Admin")
            {
                return RedirectToAction("Forbidden", "UserAccount");
            }

            var SelItm = string.IsNullOrEmpty(groupKind) ? null : ListItemGroup(groupKind);

            if (SelItm != null)
            {
                
                if (SelItm.Where(m => m.Value == Indiv).Count() < 1)
                {
                    return RedirectToAction("Forbidden", "UserAccount");
                }
                
            }

            

            ViewBag.SelItem = SelItm;

            if (string.IsNullOrEmpty(startDate))
            {
                startDate = DateTime.Now.AddMonths(-1).ToString("yyyy-MM-01");
                //endDate = Convert.ToDateTime(startDate).AddMonths(3).AddDays(-1).ToString("yyyy-MM-dd");
                endDate = Convert.ToDateTime(startDate).AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd");

            }
            ViewBag.StartDate = startDate;
            ViewBag.EndDate = endDate;
            ViewBag.Indiv = Indiv;
            ViewBag.GroupKind = groupKind;

            return View(_repo.GetIndivDetails(Indiv, gId, startDate + " 00:00", endDate + " 23:59"));


        }

        public List<SelectListItem> ListItemGroup(string GroupName)
        {
            var Listitem = new List<SelectListItem>();
            foreach (var item in _repo.GetAllMember(GroupName))
            {
                Listitem.Add(new SelectListItem
                {
                    Text = item.Name,
                    Value = item.Userid

                });

            }

            return Listitem;
        }

        public JsonResult GetIndiv(string iPer)
        {


            return Json(ListItemGroup(iPer));

        }

    }
}
