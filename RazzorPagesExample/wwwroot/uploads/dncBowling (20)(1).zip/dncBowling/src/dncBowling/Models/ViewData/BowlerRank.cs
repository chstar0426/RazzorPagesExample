﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace dncBowling.Models
{
    public class BowlerRank
    {
        public string Userid { get; set; }
       
        public int Handi { get; set; }
        public double GameAverage { get; set; }
        

    }
}
