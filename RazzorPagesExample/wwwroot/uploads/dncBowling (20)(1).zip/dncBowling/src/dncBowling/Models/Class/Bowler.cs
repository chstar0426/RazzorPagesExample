﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace dncBowling.Models
{
    public class Bowler
    {
        public int Id { get; set; }
        public string Userid { get; set; }
        public string Name { get; set; }

        public string TeamGroup { get; set; }

        public int Handi { get; set; }
        public int GameAverage { get; set; }
        public bool TeamOut { get; set; }

    }
}
