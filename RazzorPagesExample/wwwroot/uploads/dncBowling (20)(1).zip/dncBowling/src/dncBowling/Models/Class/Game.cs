﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace dncBowling.Models
{
    public enum GameKind
    {
        연습게임, 비정기전, 정기전, 토요경기, 교류전
    }

    public class Game
    {
        public int Id   { get; set; }
        [Display(Name ="시간")]
        public string PlayTime { get; set; }
        [Display(Name = "장소")]
        public string Place	{ get; set; }

        [Display(Name = "게임종류")]
        public GameKind GameKind { get; set; }
       
        [Display(Name = "세부내용")]
        public string GameContent { get; set; }

        [Display(Name = "비고")]
        public string Bigo { get; set; }
      
    }
}
