﻿Select  Teams.TeamName, Scores.PlayOrder, Bowlers.Name, Scores.Jumsu from Teams, Scores, Bowlers
where GameId = 16 and
(Scores.TeamId = Teams.id and Teams.bowler = Bowlers.UserId)
Order By TeamName, Scores.PlayOrder


Select  Scores.PlayOrder, Teams.TeamName, Bowler.Name, Scores.Jumsu from Teams, Scores, Bowler
where GameId = 1 and
(Scores.TeamId = Teams.id and Teams.bowler = Bowler.UserId)
Order By Scores.PlayOrder, TeamName



Select * From Games where bigo='redpin'

Select Bowler.Name, PlayOrder, Jumsu
from Scores, Teams, Bowler

where Scores.TeamId=2 and
	  Teams.Id=2 and
	  Teams.Bowler=Bowler.UserId
Order By Scores.Id



select  Bowler.Name, Teams.TeamName, PlayOrder, Jumsu from Scores, Teams, Bowler 
where Scores.TeamId In (select Teams.Id from teams
where GameId=1 and TeamName='B') and (Scores.TeamId=teams.Id and Bowler.UserId=Teams.Bowler)
order by TeamId, PlayOrder


select GameNum, Bowler.Name, Teams.TeamName, PlayOrder, Jumsu from Scores, Teams, Bowler 
where Scores.TeamId In (select Teams.Id from teams
where GameId=1) and (Scores.TeamId=teams.Id and Bowler.UserId=Teams.Bowler)
order by Scores.GameNum, Teams.TeamName, PlayOrder


select teams.Id, teams.TeamName, Name, BowlerOrder from teams, Bowler
where gameid=1 and Teams.Bowler=bowler.UserId
order by TeamName, BowlerOrder


Select  Scores.PlayOrder, Teams.TeamName, Bowler.Name, Scores.Jumsu 
						from Teams, Scores, Bowler
						where GameId = 1 and
						Scores.TeamId = Teams.id and
						Teams.bowler = Bowler.UserId
						Order By Scores.PlayOrder, TeamName


--///////////////////////////////////////////////////////////////////////////


select Teams.Id, Teams.TeamName, Bowlers.Name, Teams.PlayOrder, Bowlers.Handi from Teams, Bowlers
						Where  Teams.GameId=3003 and Bowlers.UserId=Teams.Bowler and (Teams.TeamName!='' and Teams.PlayOrder !=0)
						order by Teams.TeamName, Teams.PlayOrder

select Teams.Id, Teams.TeamName, Bowler.Name, Teams.PlayOrder from Teams, Bowler
						Where  Teams.GameId=@id and Bowler.UserId=Teams.Bowler
						order by Teams.TeamName, Teams.BowlerOrder
--경기별

SELECT Scores.GameNum, Scores.TeamName, Teams.Bowler, Bowlers.Name, Scores.Jumsu, Scores.PlayOrder  
FROM Scores, Teams, Bowlers
WHERE Teams.GameId=1 AND Scores.TeamId=Teams.Id AND Teams.Bowler=Bowlers.UserId
ORDER BY GameNum,  TeamName, PlayOrder

--개인별
SELECT Scores.GameNum, Scores.TeamName, Teams.Bowler, Bowlers.Name, Scores.Jumsu, Scores.PlayOrder
FROM Scores, Teams, Bowlers
WHERE Teams.GameId=1 AND Scores.TeamId=Teams.Id AND Teams.Bowler=Bowlers.UserId
ORDER BY Name, GameNum, PlayOrder

select Name, Max(Jumsu), Avg(Jumsu), Sum(Jumsu), GameAverage  from Scores, Teams, Bowlers
WHERE SCORES.TeamId=TEAMS.Id AND GAMEID=1 AND Bowlers.UserId=Teams.Bowler
group by Name, GameAverage Order by Avg(Jumsu) Desc


select Name, GameAverage from Scores, Teams, Bowlers
WHERE SCORES.TeamId=TEAMS.Id AND GAMEID=1 AND Bowlers.UserId=Teams.Bowler
group by Name, GameAverage Order by Avg(Jumsu) Desc

select Max(Jumsu) from Scores, Teams, Bowlers
WHERE Scores.TeamId=TEAMS.Id AND GAMEID=1 AND Bowlers.UserId=Teams.Bowler



Insert Into Scores (TeamId, GameNum, TeamName, PlayOrder, Jumsu)
 Values (@TeamId, @GameNum, @TeamName, @PlayOrder, @Jumsu)


-- 스코어 기록 (Teams에서 가져오기)

 select Teams.Id, Teams.TeamName, Bowlers.Name, Teams.PlayOrder, Bowlers.Handi from Teams, Bowlers
						Where  Teams.GameId=5002 and Bowlers.UserId=Teams.Bowler and (Teams.TeamName!='' and Teams.PlayOrder !=0)
						order by Teams.TeamName, Teams.PlayOrder

-- 스코어 수정 (스코어에서 가져오기)
 select Scores.Id, Scores.TeamName, Bowlers.Name, Scores.PlayOrder, Bowlers.Handi, Scores.Jumsu from Scores, Teams, Bowlers
						Where  Teams.GameId=5002 and Scores.GameNum=3 and Teams.Id=Scores.TeamId and Bowlers.UserId=Teams.Bowler
						order by Scores.TeamName, Scores.PlayOrder


-- 팀 멤버수정
select * from Bowlers

select * from bowlers
where Bowlers.UserId Not In(Select Teams.Bowler From Teams Where Teams.GameId=11007)
order by Bowlers.TeamGroup


select Teams.Id, Teams.GameId, Teams.TeamName, Teams.PlayOrder, Bowlers.UserId, Bowlers.Name, Bowlers.TeamGroup
 from Teams, Bowlers
where Teams.Bowler=Bowlers.UserId and Teams.GameId=11007
order By Teams.TeamName, Teams.PlayOrder






SELECT Scores.GameNum, Scores.TeamName, Teams.Bowler, Bowlers.Name, Scores.Jumsu, Scores.PlayOrder  
							FROM Scores, Teams, Bowlers
							WHERE Teams.GameId=14003 AND Scores.TeamId=Teams.Id AND Teams.Bowler=Bowlers.UserId





select count(GameId) from teams where teams.GameId=16002




select Bowlers.Name, Sum(Scores.Jumsu),  Sum(Scores.Jumsu) / COUNT(Scores.Jumsu)
from Scores, Teams, Games, Bowlers
Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
	and Games.GameKind=2
Group by Bowlers.Name 

select  Bowlers.Name, d.bwid, a, b
from Bowlers
left join (select Bowlers.Id as bwid, Bowlers.Name, Games.Id, Sum(Scores.Jumsu)as a, ROUND(Sum(Scores.Jumsu) / COUNT(Scores.Jumsu),6.1) as b
from Scores, Teams, Games, Bowlers
Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
	and Games.GameKind=2
Group by Games.Id, Bowlers.Id, Bowlers.Name)d on
 Bowlers.UserId =  d.bwid


Select Bowlers.UserId as UserId, Games.Id as GameId, Sum(Scores.Jumsu)as Hap, ROUND(Sum(Scores.Jumsu) / COUNT(Scores.Jumsu),6.1) as Average
from Scores, Teams, Games, Bowlers
Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
	and Games.GameKind=2
Group by Games.Id, Bowlers.UserId





---- 에버리지 월별 에버리지 -------------------------------------------------------------------
select  Bowlers.Name, stat.GameId, stat.Hap, stat.Cnt, stat.Average
from  Bowlers
left join(Select Bowlers.UserId as UserId, Games.Id as GameId, Sum(Scores.Jumsu)as Hap, COUNT(Scores.Jumsu) as Cnt, ROUND(Sum(Scores.Jumsu) / COUNT(Scores.Jumsu),6.1) as Average
from Scores, Teams, Games, Bowlers
Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
	and Games.GameKind=2
Group by Games.Id, Bowlers.UserId) as stat On Bowlers.UserId = stat.UserId




SELECT aa.Name, AverageManagers.Avg, aa.GameId, aa.Hap, aa.Cnt, aa.Average
FROM
(select Bowlers.UserId, Bowlers.Name, stat.GameId, stat.Hap, stat.Cnt, stat.Average
from  Bowlers
left join(Select Bowlers.UserId as UserId, Games.Id as GameId, Sum(Scores.Jumsu)as Hap, COUNT(Scores.Jumsu) as Cnt, ROUND(Sum(Scores.Jumsu) / COUNT(Scores.Jumsu),6.1) as Average
from Scores, Teams, Games, Bowlers
Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
	and Games.GameKind=2
Group by Games.Id, Bowlers.UserId) as stat On Bowlers.UserId = stat.UserId) as AA, AverageManagers
WHERE aa.UserId=AverageManagers.UserId

SELECT aa.UserId, aa.Name, Averages.Avg, aa.GameId, aa.Hap, aa.Cnt, aa.Average
						FROM (select Bowlers.UserId, Bowlers.Name, stat.GameId, stat.PlayTime, stat.Hap, stat.Cnt, stat.Average
						From  Bowlers left join(Select Bowlers.UserId as UserId, Games.Id as GameId, Games.PlayTime as PlayTime, Sum(Scores.Jumsu)as Hap, COUNT(Scores.Jumsu) as Cnt, ROUND(Sum(Scores.Jumsu) / COUNT(Scores.Jumsu),6.1) as Average
						from Scores, Teams, Games, Bowlers Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
						and Games.GameKind=2 and Games.PlayTime between '2017-03-01' and '2017-04-30'
						Group by Bowlers.UserId, Games.Id, Games.PlayTime) as stat On Bowlers.UserId = stat.UserId) as aa, 
						Averages WHERE aa.UserId=Averages.UserId Order by Userid, PlayTime





---- 에버리지 총 에버리지 -------------------------------------------------------------------
select  Bowlers.Name, stat.Hap, stat.Cnt, stat.Average
from  Bowlers
left join(Select Bowlers.UserId as UserId, Sum(Scores.Jumsu)as Hap, COUNT(Scores.Jumsu) as Cnt, ROUND(Sum(Scores.Jumsu)*1.0 / COUNT(Scores.Jumsu),0) as Average
from Scores, Teams, Games, Bowlers
Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
	and Games.GameKind=2 and Games.PlayTime between '2017-02-01' and '2017-04-30'
Group by Bowlers.UserId) as stat On Bowlers.UserId = stat.UserId Order by stat.Average Desc




SELECT aa.Name, Averages.Avg, aa.Hap, aa.Cnt, aa.Average
FROM
(select Bowlers.UserId, Bowlers.Name, stat.Hap, stat.Cnt, stat.Average
from  Bowlers
left join(Select Bowlers.UserId as UserId, Sum(Scores.Jumsu)as Hap, COUNT(Scores.Jumsu) as Cnt, ROUND(Sum(Scores.Jumsu) / COUNT(Scores.Jumsu),6.1) as Average
from Scores, Teams, Games, Bowlers
Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
	and Games.GameKind=2 and Games.PlayTime between '2017-03-01' and '2017-04-30'
Group by Bowlers.UserId) as stat On Bowlers.UserId = stat.UserId)AA, Averages

WHERE aa.UserId=Averages.UserId






select distinct id, games.PlayTime from games where Games.GameKind=2 and Games.PlayTime between '2017-02-01' and '2017-04-30'


Select * from Bowlers order by Bowlers.GameAverage Desc





select Bowlers.UserId, Bowlers.Name, stat.GameId, stat.PlayTime, stat.Hap, stat.Cnt, stat.Average
From  Bowlers left join(Select Bowlers.UserId as UserId, Games.Id as GameId, Games.PlayTime as PlayTime, Sum(Scores.Jumsu)as Hap, COUNT(Scores.Jumsu) as Cnt, ROUND(Sum(Scores.Jumsu) / COUNT(Scores.Jumsu),6.1) as Average
from Scores, Teams, Games, Bowlers Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
and Games.GameKind=2 and Games.PlayTime between '2017-04-01' and '2017-04-30'
Group by Bowlers.UserId, Games.Id, Games.PlayTime) as stat On Bowlers.UserId = stat.UserId


select Bowlers.UserId, Bowlers.Name, stat.GameId, stat.PlayTime, stat.Hap, stat.Cnt, stat.Average
From  Bowlers left join(Select Bowlers.UserId as UserId, Games.Id as GameId, Games.PlayTime as PlayTime, Sum(Scores.Jumsu)as Hap, COUNT(Scores.Jumsu) as Cnt, ROUND(Sum(Scores.Jumsu) / COUNT(Scores.Jumsu),6.1) as Average
from Scores, Teams, Games, Bowlers Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
and Games.GameKind=2 and Games.PlayTime between '2017-03-01' and '2017-03-31'
Group by Bowlers.UserId, Games.Id, Games.PlayTime) as stat On Bowlers.UserId = stat.UserId


Select Bowlers.UserId as UserId, Games.Id as GameId, Games.PlayTime as PlayTime, Sum(Scores.Jumsu)as Hap, COUNT(Scores.Jumsu) as Cnt, ROUND(Sum(Scores.Jumsu) / COUNT(Scores.Jumsu),6.1) as Average
from Scores, Teams, Games, Bowlers Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
and Games.GameKind=2 and Games.PlayTime between '2017-03-01' and '2017-04-30'
Group by Bowlers.UserId, Games.Id, Games.PlayTime






---------------------------------------------------------------------------
SELECT aa.UserId, aa.Name, Averages.Avg, aa.GameId, aa.Hap, aa.Cnt, aa.Average
						FROM (select Bowlers.UserId, Bowlers.Name, stat.GameId, stat.PlayTime, stat.Hap, stat.Cnt, stat.Average
						From  Bowlers left join(Select Bowlers.UserId as UserId, Games.Id as GameId, Games.PlayTime as PlayTime, Sum(Scores.Jumsu)as Hap, COUNT(Scores.Jumsu) as Cnt, ROUND(Sum(Scores.Jumsu)*1.0 / COUNT(Scores.Jumsu),0) as Average
						from Scores, Teams, Games, Bowlers Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
						and Games.GameKind=2 and Games.PlayTime between '2017-01-01' and '2017-04-30'
						Group by Bowlers.UserId, Games.Id, Games.PlayTime) as stat On Bowlers.UserId = stat.UserId) as aa, 
						Averages WHERE aa.UserId=Averages.UserId Order by Userid, PlayTime 

select Id, GameContent from Games where GameKind=2 and PlayTime between '2017-01-01' and '2017-04-30' order by playtime


Select UserId, Name, Handi from Bowlers Where TeamGroup='RedPin'  Order by GameAverage Desc



select  Bowlers.UserId, Bowlers.Name, stat.Average
from  Bowlers
left join(Select Bowlers.UserId as UserId, ROUND(Sum(Scores.Jumsu)*1.0 / COUNT(Scores.Jumsu),0) as Average
from Scores, Teams, Games, Bowlers
Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
	and Games.GameKind=2 and Games.PlayTime between '2017-02-01' and '2017-04-30'
Group by Bowlers.UserId) as stat On Bowlers.UserId = stat.UserId Order by stat.Average Desc





SELECT aa.UserId, aa.Name, aa.Handi ,Averages.Avg, aa.GameId, aa.Hap, aa.Cnt, aa.Average
						FROM (select Bowlers.UserId, Bowlers.Name, Bowlers.Handi, stat.GameId, stat.PlayTime, stat.Hap, stat.Cnt, stat.Average
						From  Bowlers left join(Select Bowlers.UserId as UserId, Games.Id as GameId, Games.PlayTime as PlayTime, Sum(Scores.Jumsu)as Hap, COUNT(Scores.Jumsu) as Cnt, ROUND(Sum(Scores.Jumsu)*1.0 / COUNT(Scores.Jumsu),0) as Average
						from Scores, Teams, Games, Bowlers Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
						and Games.GameKind=2 and Games.PlayTime between '2017-01-01' and '2017-04-30'
						Group by Bowlers.UserId, Games.Id, Games.PlayTime) as stat On Bowlers.UserId = stat.UserId) as aa, 
						Averages WHERE aa.UserId=Averages.UserId Order by Userid, PlayTime 


select UserId, Name, ROUND(Sum(Average)*1.0 / COUNT(Average),0) as ag
from(select Bowlers.UserId, Bowlers.Name, stat.Avg, stat.GameId, stat.PlayTime, stat.Hap, stat.Cnt, stat.Average
						From  Bowlers left join(Select Bowlers.UserId as UserId, Averages.Avg as Avg, Games.Id as GameId, Games.PlayTime as PlayTime, Sum(Scores.Jumsu)as Hap, COUNT(Scores.Jumsu) as Cnt, ROUND(Sum(Scores.Jumsu)*1.0 / COUNT(Scores.Jumsu),0) as Average
						from Scores, Teams, Games, Bowlers, Averages Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
						and Games.GameKind=2 and Averages.UserId=Bowlers.UserId and Games.PlayTime between '2017-01-01' and '2017-04-30' 
						Group by Bowlers.UserId, Games.Id, Games.PlayTime, Averages.Avg) as stat On Bowlers.UserId = stat.UserId) as Ft
Group by UserId, Name Order By ag desc




Select Bowlers.UserId as UserId, Games.Id as GameId, Games.PlayTime as PlayTime, Sum(Scores.Jumsu)as Hap, COUNT(Scores.Jumsu) as Cnt, ROUND(Sum(Scores.Jumsu)*1.0 / COUNT(Scores.Jumsu),0) as Average
						from Scores, Teams, Games, Bowlers Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
						and Games.GameKind=2 and Games.PlayTime between '2017-01-01' and '2017-04-30'
						Group by Bowlers.UserId, Games.Id, Games.PlayTime

Select Bowlers.UserId as UserId, Averages.Avg as Avg, Games.Id as GameId, Games.PlayTime as PlayTime, Sum(Scores.Jumsu)as Hap, COUNT(Scores.Jumsu) as Cnt, ROUND(Sum(Scores.Jumsu)*1.0 / COUNT(Scores.Jumsu),0) as Average
						from Scores, Teams, Games, Bowlers, Averages Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
						and Games.GameKind=2 and Averages.UserId=Bowlers.UserId and Games.PlayTime between '2017-01-01' and '2017-04-30' 
						Group by Bowlers.UserId, Games.Id, Games.PlayTime, Averages.Avg

select UserId, Name, sum(Average), ROUND(Sum(Average)*1.0 / COUNT(Average),0) as ag
from(SELECT aa.UserId, aa.Name, Averages.Avg, aa.GameId, aa.Hap, aa.Cnt, aa.Average
FROM (select Bowlers.UserId, Bowlers.Name, stat.GameId, stat.PlayTime, stat.Hap, stat.Cnt, stat.Average
From  Bowlers left join(Select Bowlers.UserId as UserId, Games.Id as GameId, Games.PlayTime as PlayTime, Sum(Scores.Jumsu)as Hap, COUNT(Scores.Jumsu) as Cnt, ROUND(Sum(Scores.Jumsu)*1.0 / COUNT(Scores.Jumsu),0) as Average
from Scores, Teams, Games, Bowlers Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
and Games.GameKind=2 and Games.PlayTime between '2017-02-01' and '2017-04-30'
Group by Bowlers.UserId, Games.Id, Games.PlayTime) as stat On Bowlers.UserId = stat.UserId) as aa, 
Averages WHERE aa.UserId=Averages.UserId) kk
Group by UserId, Name Order By ag desc


----------------------- 중요 ----------------------------------------
select UserId, Name, ROUND(Sum(Average)*1.0 / COUNT(Average),0) as ag
from(select Bowlers.UserId, Bowlers.Name, stat.Avg, stat.GameId, stat.PlayTime, stat.Hap, stat.Cnt, stat.Average
						From  Bowlers left join(Select Bowlers.UserId as UserId, Averages.Avg as Avg, Games.Id as GameId, Games.PlayTime as PlayTime, Sum(Scores.Jumsu)as Hap, COUNT(Scores.Jumsu) as Cnt, ROUND(Sum(Scores.Jumsu)*1.0 / COUNT(Scores.Jumsu),0) as Average
						from Scores, Teams, Games, Bowlers, Averages Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
						and Games.GameKind=2 and Averages.UserId=Bowlers.UserId and Games.PlayTime between '2017-02-01' and '2017-04-30' 
						Group by Bowlers.UserId, Games.Id, Games.PlayTime, Averages.Avg ) as stat On Bowlers.UserId = stat.UserId) as Ft
Group by UserId, Name Order By ag desc





----평균 구하기 2가지 모델 ---- (평균결과가 다르게 나옴)
select aa.UserId, aa.Name, aa.Average, isnull(aa.Average, Averages.Avg ) as perAvg
from
(select  Bowlers.UserId, Bowlers.Name, stat.Average
from  Bowlers
left join(Select Bowlers.UserId as UserId, ROUND(Sum(Scores.Jumsu)*1.0 / COUNT(Scores.Jumsu),0) as Average
from Scores, Teams, Games, Bowlers
Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
	and Games.GameKind=2 and Games.PlayTime between '2017-02-01' and '2017-04-30'
Group by Bowlers.UserId) as stat On Bowlers.UserId = stat.UserId) as aa, Averages WHERE aa.UserId=Averages.UserId
Order by perAvg Desc


select  Bowlers.UserId, Bowlers.Handi, Bowlers.Name, stat.Average
from  Bowlers
left join(Select Bowlers.UserId as UserId, ROUND(Sum(Scores.Jumsu)*1.0 / COUNT(Scores.Jumsu),0) as Average
from Scores, Teams, Games, Bowlers
Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
	and Games.GameKind=2 and Games.PlayTime between '2017-02-01' and '2017-04-30'
Group by Bowlers.UserId) as stat On Bowlers.UserId = stat.UserId Order by stat.Average Desc





------------------------------- 에버 부부 정리 ----------------------------------------------
-----------  처음작성 ------ 정기전 개별, bowlers 테이블과 합친후, 전년에버리지
SELECT aa.UserId, aa.Name, aa.Handi,  Averages.Avg as PrevAvg, aa.GameId, aa.Hap, aa.Cnt, aa.Average
						FROM (select Bowlers.UserId, Bowlers.Name, Bowlers.Handi, stat.GameId, stat.PlayTime, stat.Hap, stat.Cnt, stat.Average
						From  Bowlers left join(Select Bowlers.UserId as UserId, Games.Id as GameId, Games.PlayTime as PlayTime, 
							Sum(Scores.Jumsu)as Hap, COUNT(Scores.Jumsu) as Cnt,  CAST(ROUND(Sum(Scores.Jumsu)*1.0 / COUNT(Scores.Jumsu),0) as Int) as Average
						from Scores, Teams, Games, Bowlers Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
						and Games.GameKind=2 and Games.PlayTime between '2017-02-01' and '2017-04-30'  and Bowlers.TeamGroup='RedPin'
						Group by Bowlers.UserId, Games.Id, Games.PlayTime) as stat On Bowlers.UserId = stat.UserId where Bowlers.TeamGroup='RedPin') as aa,
						Averages WHERE aa.UserId=Averages.UserId Order by Userid, PlayTime




--- 순의 Bowlers 테이블의 순위를 사용 하려고 했음 ----- 

------ 두번째 수정본 (전년도 에버리지 처리 문제)-----------
select Bowlers.UserId, Bowlers.Name, Bowlers.Handi, stat.Avg as PrevAvg, stat.GameId, stat.Hap, stat.Cnt, stat.Average
				From  Bowlers left join(Select Bowlers.UserId as UserId, Averages.Avg as Avg, Games.Id as GameId, Games.PlayTime as PlayTime, 
				Sum(Scores.Jumsu)as Hap, COUNT(Scores.Jumsu) as Cnt, CAST(ROUND(Sum(Scores.Jumsu)*1.0 / COUNT(Scores.Jumsu),0) as Int) as Average
				from Scores, Teams, Games, Bowlers, Averages Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
				and Games.GameKind=2 and Averages.UserId=Bowlers.UserId and Games.PlayTime between '2017-03-01' and '2017-04-30' 
				Group by Bowlers.UserId, Games.Id, Games.PlayTime, Averages.Avg ) as stat On Bowlers.UserId = stat.UserId order by UserId, PlayTime

----  두번째 수정본 (순위 포함) -------------
select UserId, Name, ROUND(Sum(Average)*1.0 / COUNT(Average),0) as ag
from(select Bowlers.UserId, Bowlers.Name, Bowlers.Handi, stat.Avg as PrevAvg, stat.GameId, stat.Hap, stat.Cnt, stat.Average
						From  Bowlers left join(Select Bowlers.UserId as UserId, Averages.Avg as Avg, Games.Id as GameId, Games.PlayTime as PlayTime, 
						Sum(Scores.Jumsu)as Hap, COUNT(Scores.Jumsu) as Cnt, CAST(ROUND(Sum(Scores.Jumsu)*1.0 / COUNT(Scores.Jumsu),0) as Int) as Average
						from Scores, Teams, Games, Bowlers, Averages Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
						and Games.GameKind=2 and Averages.UserId=Bowlers.UserId and Games.PlayTime between '2017-02-01' and '2017-04-30' 
						Group by Bowlers.UserId, Games.Id, Games.PlayTime, Averages.Avg ) as stat On Bowlers.UserId = stat.UserId) as Ft
Group by UserId, Name Order By ag desc




-------------------------- 삭제하기 --------------------------------
select * from games

select id from teams where gameid=9

Select  Scores.id from Teams, Scores, Games
where GameId = 2 and Scores.GameNum>2 and
(Scores.TeamId = Teams.id and Teams.GameId = Games.Id)


delete from games where id=9

delete from teams where gameid=9

delete from Scores where id in (Select  Scores.id from Teams, Scores, Games
where GameId = 9 and (Scores.TeamId = Teams.id and Teams.GameId = Games.Id))



delete from Scores where id in (Select  Scores.id from Teams, Scores, Games
where GameId = 12  and Scores.GameNum=5 and
(Scores.TeamId = Teams.id and Teams.GameId = Games.Id))


Update Scores set GameNum=GameNum-1  where id in (Select  Scores.id from Teams, Scores, Games
where GameId = 12  and Scores.GameNum>5 and
(Scores.TeamId = Teams.id and Teams.GameId = Games.Id))


-------------------- 페이지 구현
select * From (Select Id, PlayTime, Place, GameKind, GameContent, Bigo, 
                    ROW_NUMBER() Over (Order by PlayTime Desc) As 'RowNumber'
                    from Games where Bigo='RedPin') as Tbl 
             Where Tbl.RowNumber Between 1 * 3 + 1 And (1 + 1) * 3


---------------개인별 기록
select distinct(G.Id) from Games as G, Teams as T where G.Id=T.GameId 
and T.Bowler='FA001'


select * from Games G, Teams T, Scores S where G.Id=T.GameId and T.Id=S.Teamid and T.Bowler='FA001'
Order by G.GameKind, G.PlayTime 

Select G.Id, G.PlayTime, G.Place, G.GameKind, G.GameContent, COUNT(S.Jumsu) as GameCount, ROUND(Sum(S.Jumsu)*1.0 / COUNT(S.Jumsu),0) as GameAverage From Games G, Teams T, Scores S 
Where G.Id=T.GameId and T.Id=S.Teamid and T.Bowler='FA001' 
Group by G.Id, G.PlayTime, G.Place, G.GameKind, G.GameContent Order by G.GameKind, G.PlayTime desc




Select G.Id, G.PlayTime, G.Place, G.GameKind, G.GameContent, COUNT(S.Jumsu) as GameCount, ROUND(Sum(S.Jumsu)*1.0 / COUNT(S.Jumsu),0) as GameJumsu, T.GameAverage From Games G, Teams T, Scores S 
Where G.Id=T.GameId and T.Id=S.Teamid and T.Bowler='FA001' and G.PlayTime between '2017-05-01' and '2017-05-15' 
Group by G.Id, G.PlayTime, G.Place, G.GameKind, G.GameContent, T.GameAverage Order by G.GameKind, G.PlayTime desc


SELECT S.GameNum, S.Jumsu, T.Bowler, S.PlayOrder
FROM Scores S, Teams T
WHERE T.GameId=18 AND S.TeamId=T.Id AND T.Bowler='FA001' order by GameNum


select  Bowlers.UserId, Bowlers.Handi, Bowlers.Name, stat.Average
from  Bowlers
left join(Select Bowlers.UserId as UserId, ROUND(Sum(Scores.Jumsu)*1.0 / COUNT(Scores.Jumsu),0) as Average
from Scores, Teams, Games, Bowlers
Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
	and Games.GameKind=2 and Games.PlayTime between '2017-02-01' and '2017-04-30'
Group by Bowlers.UserId) as stat On Bowlers.UserId = stat.UserId Order by stat.Average Desc

