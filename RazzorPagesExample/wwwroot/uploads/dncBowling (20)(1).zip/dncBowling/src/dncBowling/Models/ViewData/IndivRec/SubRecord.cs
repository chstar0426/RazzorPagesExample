﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace dncBowling.Models.ViewData
{
    public class SubRecord
    {
        public int GameNum { get; set; }
        public int Jumsu { get; set; }

    }
}
