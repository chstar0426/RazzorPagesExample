﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace dncBowling.Models.ViewData
{
    public class BowlerInTeams
    {
        public int Id { get; set; }
        public string TeamName { get; set; }
        public string Name { get; set; }
        public int PlayOrder { get; set; }

        public int Handi { get; set; }

        public int Jumsu { get; set; }
    }
}
