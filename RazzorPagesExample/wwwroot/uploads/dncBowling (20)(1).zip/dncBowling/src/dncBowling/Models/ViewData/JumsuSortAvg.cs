﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace dncBowling.Models.ViewData
{
    public class JumsuSortAvg
    {
        public string Userid { get; set; }
        public string Name { get; set; }

        public int Handi { get; set; }
        public int GameAverage { get; set; }
    }
}
