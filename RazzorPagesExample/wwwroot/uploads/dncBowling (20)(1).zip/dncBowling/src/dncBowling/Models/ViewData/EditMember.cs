﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace dncBowling.Models.ViewData
{
    public class EditMember
    {

        public int id { get; set; }
        public int GameId { get; set; }

        public string TeamName { get; set; }

        public int PlayOrder { get; set; }

        public string UserId { get; set; }

        public string Name { get; set; }

        public int GameAverage { get; set; }
    }
}
