﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace dncBowling.Models.ViewData
{
    public class AverargeCalc
    {
        public List<AvgByMon> AvgByMons { get; set; }
        public List<Game> GameListByPers { get; set; }
        public List<BowlerRank> BowlersByTeamAverages { get; set; }

    }
}
