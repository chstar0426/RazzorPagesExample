﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace dncBowling.Models.ViewData
{
    public class SubGame
    {
        
        public int Id { get; set; }
        [Display(Name = "시간")]
        public string PlayTime { get; set; }
        [Display(Name = "장소")]
        public string Place { get; set; }

        [Display(Name = "게임종류")]
        public GameKind GameKind { get; set; }

        [Display(Name = "세부내용")]
        public string GameContent { get; set; }

        [Display(Name = "게임수")]
        public int GameCount { get; set; }


        [Display(Name = "점수")]
        public int GameJumsu { get; set; }


        [Display(Name = "에바")]
        public int GameAverage { get; set; }



    }
}
