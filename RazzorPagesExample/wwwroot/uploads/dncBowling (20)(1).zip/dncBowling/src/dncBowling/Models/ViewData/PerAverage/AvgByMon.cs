﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace dncBowling.Models.ViewData
{
    public class AvgByMon
    {
        public string Userid { get; set; }
        public string Name { get; set; }

        public int Handi { get; set; }

        //전년도 에버리지
        public int PrevAvg { get; set; }

        public int GameId { get; set; }

        public int Hap { get; set; }
        public int Cnt { get; set; }
        public int Average { get; set; }
        

    }
}
