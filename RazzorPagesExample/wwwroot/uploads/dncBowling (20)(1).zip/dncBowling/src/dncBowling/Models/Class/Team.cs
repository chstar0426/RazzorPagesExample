﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace dncBowling.Models
{
    public class Team
    {
        public int Id { get; set; }
        public int GameId { get; set; }

        [Display(Name = "팀명")]
        public string TeamName { get; set; }

        [Display(Name = "순서")]
        public int PlayOrder { get; set; }

        [Display(Name = "에버리지")]
        public int GameAverage { get; set; }


        [Display(Name = "선수")]
        public string Bowler { get; set; }
    }
}
