﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace dncBowling.Models.ViewData
{
    public class EditTeamMember
    {
        public List<Bowler> AllMember { get; set; }
        public List<EditMember> TeamMember { get; set; }
    }
}
