﻿using dncBowling.Models.ViewData;
using System.Collections.Generic;

namespace dncBowling.Models
{
    public interface IGameRepository
    {
        List<Game> GetAllGames(string TeamGroup, int GameKind, int Page, int PageSize);

        int GetCount(string TeamGroup, int GameKind);

        Game GetGameById(int id);
        List<GameScore> GetGameScores(int id);
        int AddGame(Game model);

        int ModifyGame(Game model);

        List<BowlerInTeams> TeamsMember(int id);
        int CreateSocre(List<Score> Score);

        List<JumsuSortAvg> GameJumsuSort(int id);

        List<Bowler> AllMember(string team);

        string GameByTeam(int Id);

        List<Bowler> AllMember(int id, string teamGroup);

        int CreateTeams(List<Team> Teams);

        List<BowlerInTeams> MemberScores(int id, int num);

        int EditScores(List<Score> Score);

        List<EditMember> TeamBowler(int id);

        int EditTeams(List<Team> Teams);

        int TeamCount(int id);

        List<AvgByMon> AverageByMonth(string sdt, string edt, string teamGroup);
        //List<Bowler> BowlersByTeamAverageDesc(string sdt, string edt);

        List<Game> GameListByPer(string sdt, string edt, string teamGroup);

        int RecordAverage(List<Bowler> Bowlers);

        List<Bowler> GetAllMember(string TeamGroup);

        void DeleteScores(int GameId, int GameNum);

        void DeleteGames(int Id);

        IndivRecords GetIndivDetails(string Id, int gId, string sdt, string edt);

    }
        
}