﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace dncBowling.Models.ViewData
{
    public class GameDetails
    {
        public Game Game { get; set; }

        public List<GameScore> Scores { get; set; }


    }

    public class GameScore
    {  
        [Display(Name="경기횟수")]
        public int GameNum { get; set; }
        [Display(Name = "팀구분")]
        public string TeamName { get; set; }

        [Display(Name = "선수")]
        public string Bowler { get; set; }

        [Display(Name = "이름")]
        public string Name { get; set; }
        [Display(Name = "점수")]
        public int Jumsu { get; set; }

        [Display(Name = "순서")]
        public int PlayOrder { get; set; }

    }
}
