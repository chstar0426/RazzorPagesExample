﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace dncBowling.Models
{
    public class Score
    {

        public int Id { get; set; }
        public int TeamId { get; set; }

        [Display(Name = "횟수")]
        public int GameNum { get; set; }

        [Display(Name = "팀명")]
        public string TeamName { get; set; }


        [Display(Name = "순서")]
        public int PlayOrder { get; set; }

        [Display(Name = "점수")]
        public int Jumsu { get; set; }


    }
}
