﻿using Dapper;
using dncBowling.Models.ViewData;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace dncBowling.Models
{
   
	public class GameRepository : IGameRepository
	{
		private readonly SqlConnection _db;

		public GameRepository(IConfiguration config)
		{
			
			_db = new SqlConnection(config.GetConnectionString("DefaultConnection"));

		}

		public int GetCount(string TeamGroup, int GameKind)
		{
			var query= "Select count(id) from Games where Bigo=@TeamGroup " + (GameKind > -1 ? " and GameKind = @GameKind " : "") ;

			return _db.Query<int>(query, new { TeamGroup, GameKind }).SingleOrDefault();
		}

		public List<Game> GetAllGames(string TeamGroup, int GameKind, int Page, int PageSize)
		{
			//var query = "Select Id, PlayTime, Place, GameKind, GameContent, Bigo " +
			//       " Row_Number()over(Order by PlayTime Desc) As 'RowNumber' " +
			//       " from Games where Bigo=@TeamGroup " + (GameKind > -1 ? " and GameKind = @GameKind " : "");


			//query = @"Select Id, PlayTime, Place, GameKind, GameContent, Bigo 
			//        Row_Number()over(Order by PlayTime Desc) As 'RowNumber'
			//        from Games where Bigo=@TeamGroup ";

			
			var query = "select * From (Select Id, PlayTime, Place, GameKind, GameContent, Bigo, " +
					" ROW_NUMBER() Over (Order by PlayTime Desc) As 'RowNumber' " +
					" from Games where Bigo=@TeamGroup " + (GameKind > -1 ? " and GameKind = @GameKind " : "") + " ) as Tbl " +
			"  Where Tbl.RowNumber Between @Page * @PageSize + 1 And (@Page + 1) * @PageSize";

			return _db.Query<Game>(query, new { TeamGroup, GameKind, Page, PageSize }).ToList();
		}

		public Game GetGameById(int id)
		{
			var query = @"Select * from Games Where Id=@Id";
			return _db.Query<Game>(query, new { id }).SingleOrDefault();
		}

		public List<GameScore> GetGameScores(int id)
		{
			var query = @"SELECT Scores.GameNum, Scores.TeamName, Teams.Bowler, Bowlers.Name, Scores.Jumsu, Scores.PlayOrder  
							FROM Scores, Teams, Bowlers
							WHERE Teams.GameId=@id AND Scores.TeamId=Teams.Id AND Teams.Bowler=Bowlers.UserId";

			return _db.Query<GameScore>(query, new { id }).ToList();
		}



		public int AddGame(Game model)
		{
			var query = @"Insert Into Games (PlayTime, Place, GameKind, GameContent, Bigo)
						Values (@PlayTime, @Place, @GameKind, @GameContent, @Bigo); 
						Select Cast(Scope_Identity() as Int); ";


			return _db.Query<int>(query, model).SingleOrDefault();
			
		}


		public int ModifyGame(Game model)
		{
			var sql = @"Update Games Set PlayTime =@PlayTime, Place = @Place, GameKind= @GameKind, GameContent=@GameContent, Bigo=@Bigo Where Id=@Id";

			return _db.Execute(sql,model);


			


		}


		public List<BowlerInTeams> TeamsMember(int id)
		{
			var query = @"select Teams.Id, Teams.TeamName, Bowlers.Name, Teams.PlayOrder, Bowlers.Handi from Teams, Bowlers
						Where  Teams.GameId=@id and Bowlers.UserId=Teams.Bowler and (Teams.TeamName!='' and Teams.PlayOrder !=0)
						order by Teams.TeamName, Teams.PlayOrder";

			return _db.Query<BowlerInTeams>(query, new { id }).ToList();

		}

		public List<BowlerInTeams> MemberScores(int id, int num)
		{
			var query = @"select Scores.Id, Scores.TeamName, Bowlers.Name, Scores.PlayOrder, Bowlers.Handi, Scores.Jumsu from Scores, Teams, Bowlers
						Where  Teams.GameId=@id and Scores.GameNum=@num and Teams.Id=Scores.TeamId and Bowlers.UserId=Teams.Bowler
						order by Scores.TeamName, Scores.PlayOrder";

			return _db.Query<BowlerInTeams>(query, new { id, num }).ToList();

		}

		public int CreateSocre(List<Score> Score)
		{
			string sql = "Insert Into Scores (TeamId, GameNum, TeamName, PlayOrder, Jumsu) " +
				" Values (@TeamId, @GameNum, @TeamName, @PlayOrder, @Jumsu);";

			return _db.Execute(sql, Score);
			
		}

		public int EditScores(List<Score> Score)
		{
			string sql = @"Update Scores Set Jumsu = @Jumsu Where Id = @Id";

			return _db.Execute(sql, Score);

		}

		public List<JumsuSortAvg> GameJumsuSort(int id)
		{
			string sql = @"select UserId, Name, Handi, Teams.GameAverage from Scores, Teams, Bowlers
						WHERE SCORES.TeamId=TEAMS.Id AND GAMEID=@id AND Bowlers.UserId=Teams.Bowler
						group by Bowlers.UserId, Bowlers.Name, Teams.GameAverage, Bowlers.Handi Order by round(Avg(Jumsu*1.0),1) Desc";

			return _db.Query<JumsuSortAvg>(sql, new { id }).ToList();
		}


		public List<Bowler> AllMember(string team)
		{
			string sql = @"Select * From Bowlers Where TeamGroup=@team Order by Name";
			return _db.Query<Bowler>(sql, new { team }).ToList();
		}

		public string GameByTeam(int Id)
		{
			string sql= @"SELECT Bigo FROM games WHERE Id=@Id";

			return _db.Query<string>(sql, new { Id }).SingleOrDefault();
		}


		public int CreateTeams(List<Team> Teams)
		{
			string sql = "insert into Teams (GameId, TeamName, PlayOrder, GameAverage, Bowler) " +
				" values (@GameId, @TeamName, @PlayOrder, @GameAverage, @Bowler)";

			return _db.Execute(sql, Teams);

		}

		public List<Bowler> AllMember(int id, string teamGroup)
		{
			string sql = @"select * from bowlers
				where Bowlers.UserId Not In(Select Teams.Bowler From Teams Where Teams.GameId= @id and (Teams.TeamName!='' and Teams.PlayOrder !=0))
				and Bowlers.TeamGroup=@teamGroup Order by Bowlers.Name";
			return _db.Query<Bowler>(sql, new { id, teamGroup }).ToList();
		}

		public List<EditMember> TeamBowler(int id)
		{
			string sql = @"select Teams.Id, Teams.GameId, Teams.TeamName, Teams.PlayOrder, Bowlers.UserId, Bowlers.Name, Teams.GameAverage
						 from Teams, Bowlers where Teams.Bowler=Bowlers.UserId and Teams.GameId=@Id and (Teams.TeamName!='' and Teams.PlayOrder !=0)
						order By Teams.TeamName, Teams.PlayOrder";

			return _db.Query<EditMember>(sql, new { id }).ToList();
		}


		public int EditTeams(List<Team> Teams)
		{
			string sql = @"Update Teams Set TeamName=@TeamName, PlayOrder=@PlayOrder Where Id = @Id";

			return _db.Execute(sql, Teams);

		}


		public int TeamCount(int id)
		{
			
			string sql = @"select count(GameId)from teams where teams.GameId = @id";
			return _db.Query<int>(sql, new { id }).SingleOrDefault();
		}




		///

		public List<AvgByMon> AverageByMonth(string sdt, string edt, string teamGroup)
		{
			string sql = @"SELECT aa.UserId, aa.Name, aa.Handi,  Averages.Avg as PrevAvg, aa.GameId, aa.Hap, aa.Cnt, aa.Average
						FROM (select Bowlers.UserId, Bowlers.Name, Bowlers.Handi, stat.GameId, stat.PlayTime, stat.Hap, stat.Cnt, stat.Average
						From  Bowlers left join(Select Bowlers.UserId as UserId, Games.Id as GameId, Games.PlayTime as PlayTime, 
							Sum(Scores.Jumsu)as Hap, COUNT(Scores.Jumsu) as Cnt,  CAST(ROUND(Sum(Scores.Jumsu)*1.0 / COUNT(Scores.Jumsu),0) as Int) as Average
						from Scores, Teams, Games, Bowlers Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
						and Games.GameKind=2 and Games.PlayTime between @sdt and @edt  and Bowlers.TeamGroup=@teamGroup
						Group by Bowlers.UserId, Games.Id, Games.PlayTime) as stat On Bowlers.UserId = stat.UserId where Bowlers.TeamGroup=@teamGroup) as aa,
						Averages WHERE aa.UserId=Averages.UserId Order by Userid, PlayTime
";

			return _db.Query<AvgByMon>(sql, new {sdt, edt, teamGroup}).ToList();

		}

		//public List<Bowler> BowlersByTeamAverageDesc(string sdt, string edt)
		//{
		//    //string sql = @"Select UserId, Handi from Bowlers Where TeamGroup = 'RedPin'  Order by GameAverage Desc";

		//    string sql = @"select  Bowlers.UserId, Bowlers.Handi
		//                from  Bowlers
		//                left join(Select Bowlers.UserId as UserId, ROUND(Sum(Scores.Jumsu)*1.0 / COUNT(Scores.Jumsu),0) as Average
		//                from Scores, Teams, Games, Bowlers
		//                Where Teams.Id=Scores.TeamId and Games.id=Teams.GameId and Bowlers.UserId=Teams.Bowler
		//                    and Games.GameKind=2 and Games.PlayTime between @sdt and @edt
		//                Group by Bowlers.UserId) as stat On Bowlers.UserId = stat.UserId Order by stat.Average Desc";

		//    return _db.Query<Bowler>(sql, new { sdt, edt }).ToList();
			
		//}


		public List<Game> GameListByPer(string sdt, string edt, string teamGroup)
		{
			string sql = @"select Id, GameContent from Games where GameKind=2 and PlayTime between @sdt and @edt and Bigo=@teamGroup order by playtime ";
			return _db.Query<Game>(sql, new { sdt, edt, teamGroup }).ToList();
		}


		public int RecordAverage(List<Bowler> Bowlers)
		{
			string sql = @"Update Bowlers Set GameAverage = @GameAverage Where UserId = @UserId";

			return _db.Execute(sql, Bowlers);

		}


		public List<Bowler> GetAllMember(string TeamGroup)
		{
			string sql = "Select * from Bowlers Where TeamGroup=@TeamGroup";
			return _db.Query<Bowler>(sql, new { TeamGroup }).ToList();
		}

		public void DeleteScores(int GameId, int GameNum)
		{

			string sql = @"delete from Scores where id in (Select  Scores.id from Teams, Scores, Games
						where GameId = @GameId  and Scores.GameNum=@GameNum and
						(Scores.TeamId = Teams.id and Teams.GameId = Games.Id))";
			_db.Execute(sql, new { GameId, GameNum });



			sql = @" Update Scores set GameNum = GameNum - 1  where id in (Select  Scores.id from Teams, Scores, Games
						where GameId = @GameId  and Scores.GameNum>@GameNum and
						  (Scores.TeamId = Teams.id and Teams.GameId = Games.Id))";
			_db.Execute(sql, new { GameId, GameNum });

			
		}

		public void DeleteGames(int Id)
		{
			string sql = @"delete from Scores where id in (Select  Scores.id from Teams, Scores, Games
				where GameId = @Id and (Scores.TeamId = Teams.id and Teams.GameId = Games.Id))";
			_db.Execute(sql, new { Id });

			sql = "delete from teams where gameid = @id";
			_db.Execute(sql, new { Id });


			sql = "delete from games where id = @Id";
			_db.Execute(sql, new { Id});

			
		}

		public IndivRecords GetIndivDetails(string Id, int gId, string sdt, string edt)
		{
			var sql = @"Select G.Id, G.PlayTime, G.Place, G.GameKind, G.GameContent, COUNT(S.Jumsu) as GameCount, ROUND(Sum(S.Jumsu)*1.0 / COUNT(S.Jumsu),0) as GameJumsu, T.GameAverage
						From Games G, Teams T, Scores S Where G.Id=T.GameId and T.Id=S.Teamid and T.Bowler=@Id and G.PlayTime between @sdt and @edt
						Group by G.Id, G.PlayTime, G.Place, G.GameKind, G.GameContent, T.GameAverage Order by G.GameKind, G.PlayTime Desc;" +
					 @"SELECT S.GameNum, S.Jumsu, T.Bowler, S.PlayOrder FROM Scores S, Teams T
						WHERE T.GameId=@gId AND S.TeamId=T.Id AND T.Bowler=@Id order by GameNum;";

			var MulData = new IndivRecords();

			using (var MulRecords = _db.QueryMultiple(sql, new { Id = Id, gId = gId, sdt=sdt, edt=edt }))
			{
				var subGames = MulRecords.Read<SubGame>().ToList();
				var subRecords = MulRecords.Read<SubRecord>().ToList();

				if (subGames!=null)
				{
					MulData.SubGames.AddRange(subGames);
				}
				if (subRecords!=null)
				{
					MulData.SubRecords.AddRange(subRecords);
				}
			}

			return MulData;

		}
	}
}
