﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace dncBowling.Models.ViewData
{
    public class IndivRecords
    {
        public IndivRecords()
        {
            SubGames = new List<SubGame>();
            SubRecords = new List<SubRecord>();
        }

        public List<SubGame> SubGames { get; set; }
        public List<SubRecord> SubRecords { get; set; }



    }
}
