﻿CREATE TABLE [dbo].[Teams]
(
	[Id] INT NOT NULL identity(1,1) PRIMARY KEY,
	[GameId] INT NOT NULL,
	[TeamName] nvarchar(50) not null,
	[PlayOrder] int Not null,
	[GameAverage] int Not null,
	[Bowler] nvarchar(50) Not null
	

)
