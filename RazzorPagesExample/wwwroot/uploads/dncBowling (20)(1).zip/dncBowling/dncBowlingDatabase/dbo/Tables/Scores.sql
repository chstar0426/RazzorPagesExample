﻿CREATE TABLE [dbo].[Scores]
(

	[Id] INT NOT NULL identity(1,1) PRIMARY KEY,
	[TeamId] Int not null,
	[GameNum] int not null,
	[TeamName] nvarchar(50) not null,
	[PlayOrder] int not null,
	[Jumsu] int not null

)
