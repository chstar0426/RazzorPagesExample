﻿CREATE TABLE [dbo].[Bowlers]
(
	[Id] INT NOT NULL identity(1,1) PRIMARY KEY,
	UserId nvarchar(50) not null,
	Name nvarchar(50) not null,
	TeamGroup nvarchar(50) not null,
	Handi Int Null,
	GameAverage Int Null,
	TeamOut Bit null
)
