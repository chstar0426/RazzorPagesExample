﻿CREATE TABLE [dbo].[Averages]
(

	[Id] INT NOT NULL Identity(1,1) PRIMARY KEY,
	[UserId] nvarchar(50) Null,
	[Year] nvarchar(4) not null,
	[Month] nvarchar(2) not null,
	[Avg] INT not null

	
)
