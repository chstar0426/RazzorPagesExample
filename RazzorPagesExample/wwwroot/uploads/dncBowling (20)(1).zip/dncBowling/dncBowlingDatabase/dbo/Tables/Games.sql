﻿CREATE TABLE [dbo].[Games]
(
	[Id]		INT NOT NULL identity(1,1) PRIMARY KEY,
	PlayTime	Datetime default(getdate()) not null,
	Place		nVarchar(50) null,
	GameKind	int default(0) not null,
	GameContent nvarchar(50) null,
	Bigo	    nvarchar(Max) null
)
